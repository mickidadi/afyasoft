(function($) {
	"use strict";
	
	//P-scrolling
	const ps = new PerfectScrollbar('.app-sidebar3', {
	  useBothWheelAxes:true,
	  suppressScrollX:true,
	});
	
})(jQuery);